﻿

' AUTHOR: CoffeeCodeConverter
' CREATION DATE: 23/02/2025

'REQUIREMENTS:
'.NET Framework 4.5.1 Or higher


' DESCRIPTION:
' A Module For simulation Mouse Events using Windows Hooks.
' Provides easy to use Functions that smoothly animate mouse events, with full granular control of each state. 
' can work Asynchronously / Synchronously 


' Usable Functions
'    Await MoveCursor(x, y, durationMs, fps, easing)
'    Await ClickAndDrag(startX, startY, endX, endY, durationMs, fps, easing)
'    DoLeftDown()
'    DoLeftUp()
'    DoLeftClick()
'    DoLeftDoubleClick()
'    DoRightDown()
'    DoRightUp()
'    DoRightClick()
'    DoMiddleDown()
'    DoMiddleUp()
'    DoMiddleClick()s
'    DoMouseScroll(scrollAmountInt)
'    DoKeepMouseInPlace()
'    ResetMouseState()
'    NonBlockingWait(waitInMs)





Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Threading.Tasks



Module HookMouse


    <DllImport("user32.dll", SetLastError:=True)>
    Private Function SetCursorPos(x As Integer, y As Integer) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Function GetCursorPos(ByRef lpPoint As Point) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Sub mouse_event(ByVal dwFlags As UInteger, ByVal dx As Integer, ByVal dy As Integer, ByVal dwData As Integer, ByVal dwExtraInfo As UInteger)
    End Sub



    ' Mouse event flags
    Private Const MOUSEEVENTF_LEFTDOWN As UInteger = &H2
    Private Const MOUSEEVENTF_LEFTUP As UInteger = &H4
    Private Const MOUSEEVENTF_RIGHTDOWN As UInteger = &H8
    Private Const MOUSEEVENTF_RIGHTUP As UInteger = &H10
    Private Const MOUSEEVENTF_MIDDLEDOWN As UInteger = &H20
    Private Const MOUSEEVENTF_MIDDLEUP As UInteger = &H40
    Private Const MOUSEEVENTF_WHEEL As UInteger = &H800
    Private Const WHEEL_DELTA As Integer = 120  ' Number of "steps" per scroll



    ' Global variables
    Public versionNumber_HookMouse As String = "1.0.0.0"
    Private currentPos As Point
    Private animationTimer As Timer
    Private startPos As Point
    Private endPos As Point
    Private startTime As DateTime
    Private animationDuration As Double
    Private easingFunction As Func(Of Double, Double)
    Public mouseAutomationInProgress As Boolean = False
    Public logMouseActivity As Boolean = False



    ' USABLE FUNCTIONS 
    ' ================================

    Public Async Function MoveCursor(x As Integer, y As Integer, durationMs As Integer, Optional fps As Integer = 60, Optional easing As Func(Of Double, Double) = Nothing) As Task
        UpdateCurrentPosition()
        mouseAutomationInProgress = True

        If easing IsNot Nothing Then
            easingFunction = easing
        End If

        endPos = New Point(x, y)
        animationDuration = durationMs / 1000
        startPos = New Point(currentPos.X, currentPos.Y)
        startTime = DateTime.Now

        If animationTimer IsNot Nothing Then
            animationTimer.Dispose()
        End If

        Dim timerInterval As Integer = Math.Round(1000 \ fps)
        animationTimer = New Timer(AddressOf AnimationTick, Nothing, 0, timerInterval)
        Await NonBlockingWait(durationMs)
    End Function




    Public Async Function ClickAndDrag(startX As Integer, startY As Integer, endX As Integer, endY As Integer, durationMs As Integer, Optional fps As Integer = 60, Optional easing As Func(Of Double, Double) = Nothing) As Task
        If easing IsNot Nothing Then
            easingFunction = easing
        End If

        Await HookMouse.MoveCursor(startX, startY, durationMs, fps, easingFunction)
        HookMouse.DoLeftDown()

        Await HookMouse.MoveCursor(endX, endY, durationMs, fps, easingFunction)
        HookMouse.DoLeftUp()
    End Function





    Public Sub DoLeftDown()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_LEFTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Left Down           x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoLeftUp()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_LEFTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Left Up             x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoLeftClick()
        UpdateCurrentPosition()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Left Click          x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        mouse_event(MOUSEEVENTF_LEFTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_LEFTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
    End Sub

    Public Sub DoLeftDoubleClick()
        UpdateCurrentPosition()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Left Double Click   x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        mouse_event(MOUSEEVENTF_LEFTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_LEFTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_LEFTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_LEFTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
    End Sub



    Public Sub DoRightDown()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_RIGHTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Right Down          x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoRightUp()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_RIGHTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Right Up            x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoRightClick()
        UpdateCurrentPosition()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Right Click         x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        mouse_event(MOUSEEVENTF_RIGHTDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_RIGHTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
    End Sub




    Public Sub DoMiddleDown()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_MIDDLEDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Middle Down         x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoMiddleUp()
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_MIDDLEUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        ConsoleLog(DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Middle Up           x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
    End Sub

    Public Sub DoMiddleClick()
        UpdateCurrentPosition()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Middle Click        x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        mouse_event(MOUSEEVENTF_MIDDLEDOWN, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        Application.DoEvents()
        mouse_event(MOUSEEVENTF_MIDDLEUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
    End Sub




    Public Async Function DoMouseScroll(ByVal clicks As Integer) As Task
        Dim potentialDelta As Integer = (clicks * WHEEL_DELTA)
        Dim durationMsToWait As Integer = 300 * Math.Abs(clicks)
        UpdateCurrentPosition()
        mouse_event(MOUSEEVENTF_WHEEL, 0, 0, potentialDelta, 0)
        Application.DoEvents()
        Dim logMessageScrollDirection As String = ""
        If clicks < 0 Then
            logMessageScrollDirection = "Down "
        Else
            logMessageScrollDirection = "Up   "
        End If
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Mouse Scroll " & logMessageScrollDirection & "        x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        Await NonBlockingWait(durationMsToWait)
        mouseAutomationInProgress = False
    End Function




    Public Async Function DoKeepMouseInPlace(Optional durationMs As Integer = 200) As Task
        UpdateCurrentPosition()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Keep Mouse in Place       x:" & currentPos.X & " y:" & currentPos.Y, logMouseActivity)
        Dim keepAtX As Integer = currentPos.X
        Dim keepAtY As Integer = currentPos.Y
        Dim durationQuartered As Integer = Math.Round(durationMs / 4)
        Await MoveCursor(keepAtX + 1, keepAtY + 0, durationMs)
        Await MoveCursor(keepAtX + 1, keepAtY + 1, durationMs)
        Await MoveCursor(keepAtX + 0, keepAtY + 1, durationMs)
        Await MoveCursor(keepAtX + 0, keepAtY + 0, durationMs)
        mouseAutomationInProgress = False
    End Function



    Public Sub ResetMouseState()
        ConsoleLog(vbCrLf & DateTime.Now.ToString("HH:mm:ss:ffffff") & " Reset Mouse State", logMouseActivity)
        mouse_event(MOUSEEVENTF_LEFTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        mouse_event(MOUSEEVENTF_RIGHTUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        mouse_event(MOUSEEVENTF_MIDDLEUP, CUInt(currentPos.X), CUInt(currentPos.Y), 0, 0)
        mouseAutomationInProgress = False
        If animationTimer IsNot Nothing Then
            animationTimer.Dispose()
        End If
    End Sub



    Public Async Function NonBlockingWait(delayMilliseconds As Integer, Optional callback As Action = Nothing) As Task
        ' AWAIT the delay
        Await Task.Delay(delayMilliseconds)
        callback?.Invoke()
    End Function



    ' ================================


    Public Sub SetCursorPosition(x As Integer, y As Integer)
        currentPos = New Point(x, y)
        SetCursorPos(x, y)
    End Sub

    Private Sub UpdateCurrentPosition()
        GetCursorPos(currentPos)
    End Sub

    Public Sub SetEasingFunction(easing As Func(Of Double, Double))
        easingFunction = easing
    End Sub


    Private Sub AnimationTick(state As Object)
        Dim elapsedTime As Double = (DateTime.Now - startTime).TotalSeconds
        If elapsedTime >= animationDuration Then
            ' If the duration is complete, set the cursor to the final position
            SetCursorPosition(endPos.X, endPos.Y)
            animationTimer.Change(Timeout.Infinite, Timeout.Infinite) ' Stop the timer
            mouseAutomationInProgress = False
        Else
            ' Calculate the current position based on the easing function
            Dim progress As Double = easingFunction(elapsedTime / animationDuration)
            Dim x As Integer = CInt(startPos.X + (endPos.X - startPos.X) * progress)
            Dim y As Integer = CInt(startPos.Y + (endPos.Y - startPos.Y) * progress)
            SetCursorPosition(x, y)
        End If
    End Sub



    Private Sub ConsoleLog(message As String, Optional logMessages As Boolean = False)
        If logMessages = True Then
            Console.WriteLine(message)
        End If
    End Sub



    Sub Initialize()
        easingFunctions.Clear()
        easingFunctions.Add("LinearEasing", AddressOf LinearEasing)
        easingFunctions.Add("EaseOutCubic", AddressOf EaseOutCubic)
        easingFunctions.Add("EaseOutQuart", AddressOf EaseOutQuart)
        easingFunctions.Add("EaseOutQuint", AddressOf EaseOutQuint)
        easingFunctions.Add("EaseOutSept", AddressOf EaseOutSept)
        easingFunctions.Add("EaseInOutCubic", AddressOf EaseInOutCubic)
        easingFunctions.Add("EaseInOutQuart", AddressOf EaseInOutQuart)
        easingFunctions.Add("EaseInOutQuint", AddressOf EaseInOutQuint)
        easingFunctions.Add("EaseInOutSept", AddressOf EaseInOutSept)
        easingFunctions.Add("EaseOutElasticQuad", AddressOf EaseOutElasticQuad)
        easingFunctions.Add("EaseOutElasticCubic", AddressOf EaseOutElasticCubic)
        easingFunctions.Add("EaseOutElasticQuart", AddressOf EaseOutElasticQuart)
        easingFunctions.Add("EaseOutBounceQuad", AddressOf EaseOutBounceQuad)
        easingFunctions.Add("EaseOutBounceCubic", AddressOf EaseOutBounceCubic)
    End Sub





    ' EASING FUNCTIONS
    ' ==================================================
    Public easingFunctions As New Dictionary(Of String, Func(Of Double, Double))


    ' THIS IS LINEAR - NO EASING
    Public Function LinearEasing(t As Double) As Double
        Return t
    End Function



    ' EASE OUT
    Public Function EaseOutCubic(t As Double) As Double
        Return 1 - (1 - t) * (1 - t) * (1 - t)
    End Function

    Public Function EaseOutQuart(t As Double) As Double
        Return 1 - (1 - t) * (1 - t) * (1 - t) * (1 - t)
    End Function

    Public Function EaseOutQuint(t As Double) As Double
        Return 1 - (1 - t) * (1 - t) * (1 - t) * (1 - t) * (1 - t)
    End Function

    Public Function EaseOutSept(t As Double) As Double
        Return 1 - (1 - t) * (1 - t) * (1 - t) * (1 - t) * (1 - t) * (1 - t) * (1 - t)
    End Function




    ' EASE IN AND OUT
    Public Function EaseInOutCubic(t As Double) As Double
        If t < 0.5 Then
            Return 4 * t * t * t
        Else
            Return 1 - (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) / 2
        End If
    End Function

    Public Function EaseInOutQuart(t As Double) As Double
        If t < 0.5 Then
            Return 8 * t * t * t * t
        Else
            Return 1 - (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) / 2
        End If
    End Function

    Public Function EaseInOutQuint(t As Double) As Double
        If t < 0.5 Then
            Return 16 * t * t * t * t * t
        Else
            Return 1 - (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) / 2
        End If
    End Function

    Public Function EaseInOutSept(t As Double) As Double
        If t < 0.5 Then
            Return 128 * t * t * t * t * t * t * t
        Else
            Return 1 - (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) * (-2 * t + 2) / 2
        End If
    End Function




    ' EASE OUT ELASTIC
    Public Function EaseOutElasticQuad(t As Double) As Double
        Return Math.Sin(-13 * Math.PI / 2 * (t + 1)) * Math.Pow(2, -10 * t) + 1
    End Function

    Public Function EaseOutElasticCubic(t As Double) As Double
        Return Math.Sin(-13 * Math.PI / 2 * (t + 1)) * Math.Pow(2, -10 * t) + 1
    End Function

    Public Function EaseOutElasticQuart(t As Double) As Double
        Return Math.Sin(-13 * Math.PI / 2 * (t + 1)) * Math.Pow(2, -10 * t) + 1
    End Function




    ' EASE OUT BOUNCE
    Public Function EaseOutBounceQuad(t As Double) As Double
        If t < 1 / 2.75 Then
            Return 7.5625 * t * t
        ElseIf t < 2 / 2.75 Then
            t -= 1.5 / 2.75
            Return 7.5625 * t * t + 0.75
        ElseIf t < 2.5 / 2.75 Then
            t -= 2.25 / 2.75
            Return 7.5625 * t * t + 0.9375
        Else
            t -= 2.625 / 2.75
            Return 7.5625 * t * t + 0.984375
        End If
    End Function

    Public Function EaseOutBounceCubic(t As Double) As Double
        If t < 1 / 2.75 Then
            Return 7.5625 * t * t * t
        ElseIf t < 2 / 2.75 Then
            t -= 1.5 / 2.75
            Return 7.5625 * t * t * t + 0.75
        ElseIf t < 2.5 / 2.75 Then
            t -= 2.25 / 2.75
            Return 7.5625 * t * t * t + 0.9375
        Else
            t -= 2.625 / 2.75
            Return 7.5625 * t * t * t + 0.984375
        End If
    End Function


End Module

