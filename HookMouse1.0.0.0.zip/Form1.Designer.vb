﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button_TestAll = New System.Windows.Forms.Button()
        Me.TextBox_X = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBox_Y = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label_XValue = New System.Windows.Forms.Label()
        Me.Label_YValue = New System.Windows.Forms.Label()
        Me.Timer_UpdateUI = New System.Windows.Forms.Timer(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox_Duration = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button_Test = New System.Windows.Forms.Button()
        Me.Button_TestClickAndDrag = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Button_TestClick = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox_EasingFunction = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBox_FPS = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button_State_Reset = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_Event_LeftDown = New System.Windows.Forms.Button()
        Me.Button_Event_LeftUp = New System.Windows.Forms.Button()
        Me.Button_Event_LeftClick = New System.Windows.Forms.Button()
        Me.Button_Event_LeftDoubleClick = New System.Windows.Forms.Button()
        Me.Button_Event_RightDown = New System.Windows.Forms.Button()
        Me.Button_Event_RightUp = New System.Windows.Forms.Button()
        Me.Button_Event_RightClick = New System.Windows.Forms.Button()
        Me.Button_Event_MiddleDown = New System.Windows.Forms.Button()
        Me.Button_Event_MiddleUp = New System.Windows.Forms.Button()
        Me.Button_Event_MiddleClick = New System.Windows.Forms.Button()
        Me.Button_Event_ScrollDown = New System.Windows.Forms.Button()
        Me.Button_Event_ScrollUp = New System.Windows.Forms.Button()
        Me.Label_StateValue = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button_RecentreWindow = New System.Windows.Forms.Button()
        Me.CheckBox_LogActivity = New System.Windows.Forms.CheckBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_TestAll
        '
        Me.Button_TestAll.Location = New System.Drawing.Point(253, 175)
        Me.Button_TestAll.Name = "Button_TestAll"
        Me.Button_TestAll.Size = New System.Drawing.Size(66, 23)
        Me.Button_TestAll.TabIndex = 7
        Me.Button_TestAll.Text = "Test All"
        Me.Button_TestAll.UseVisualStyleBackColor = True
        '
        'TextBox_X
        '
        Me.TextBox_X.Location = New System.Drawing.Point(21, 0)
        Me.TextBox_X.Name = "TextBox_X"
        Me.TextBox_X.Size = New System.Drawing.Size(42, 20)
        Me.TextBox_X.TabIndex = 3
        Me.TextBox_X.Text = "936"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(12, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "x"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TextBox_X)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(13, 80)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(66, 21)
        Me.Panel1.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TextBox_Y)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(85, 80)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(66, 21)
        Me.Panel2.TabIndex = 4
        '
        'TextBox_Y
        '
        Me.TextBox_Y.Location = New System.Drawing.Point(21, 0)
        Me.TextBox_Y.Name = "TextBox_Y"
        Me.TextBox_Y.Size = New System.Drawing.Size(42, 20)
        Me.TextBox_Y.TabIndex = 4
        Me.TextBox_Y.Text = "468"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 2)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(12, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "y"
        '
        'Label_XValue
        '
        Me.Label_XValue.AutoSize = True
        Me.Label_XValue.Location = New System.Drawing.Point(19, 104)
        Me.Label_XValue.Name = "Label_XValue"
        Me.Label_XValue.Size = New System.Drawing.Size(39, 13)
        Me.Label_XValue.TabIndex = 5
        Me.Label_XValue.Text = "Label3"
        '
        'Label_YValue
        '
        Me.Label_YValue.AutoSize = True
        Me.Label_YValue.Location = New System.Drawing.Point(91, 104)
        Me.Label_YValue.Name = "Label_YValue"
        Me.Label_YValue.Size = New System.Drawing.Size(39, 13)
        Me.Label_YValue.TabIndex = 6
        Me.Label_YValue.Text = "Label4"
        '
        'Timer_UpdateUI
        '
        Me.Timer_UpdateUI.Interval = 30
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.TextBox_Duration)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Location = New System.Drawing.Point(13, 23)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(138, 21)
        Me.Panel3.TabIndex = 1
        '
        'TextBox_Duration
        '
        Me.TextBox_Duration.Location = New System.Drawing.Point(93, 0)
        Me.TextBox_Duration.Name = "TextBox_Duration"
        Me.TextBox_Duration.Size = New System.Drawing.Size(42, 20)
        Me.TextBox_Duration.TabIndex = 1
        Me.TextBox_Duration.Text = "1000"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(1, 2)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label3.Size = New System.Drawing.Size(52, 19)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Time (ms)"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button_Test)
        Me.GroupBox1.Controls.Add(Me.Button_TestClickAndDrag)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Panel5)
        Me.GroupBox1.Controls.Add(Me.Button_TestClick)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.ComboBox_EasingFunction)
        Me.GroupBox1.Controls.Add(Me.Panel4)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.Button_TestAll)
        Me.GroupBox1.Controls.Add(Me.Label_YValue)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.Label_XValue)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 68)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(513, 219)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Arguments"
        '
        'Button_Test
        '
        Me.Button_Test.Location = New System.Drawing.Point(10, 175)
        Me.Button_Test.Name = "Button_Test"
        Me.Button_Test.Size = New System.Drawing.Size(66, 23)
        Me.Button_Test.TabIndex = 12
        Me.Button_Test.Text = "Test"
        Me.Button_Test.UseVisualStyleBackColor = True
        '
        'Button_TestClickAndDrag
        '
        Me.Button_TestClickAndDrag.Location = New System.Drawing.Point(148, 175)
        Me.Button_TestClickAndDrag.Name = "Button_TestClickAndDrag"
        Me.Button_TestClickAndDrag.Size = New System.Drawing.Size(99, 23)
        Me.Button_TestClickAndDrag.TabIndex = 11
        Me.Button_TestClickAndDrag.Text = "Test Click && Drag"
        Me.Button_TestClickAndDrag.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(157, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Test Scrolling:"
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.RichTextBox1)
        Me.Panel5.Location = New System.Drawing.Point(157, 47)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(328, 122)
        Me.Panel5.TabIndex = 9
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox1.Size = New System.Drawing.Size(326, 120)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = "sdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "as" & Global.Microsoft.VisualBasic.ChrW(10) & "df" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asd" & Global.Microsoft.VisualBasic.ChrW(10) & "fas" & Global.Microsoft.VisualBasic.ChrW(10) & "df" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "as" & Global.Microsoft.VisualBasic.ChrW(10) & "df" & Global.Microsoft.VisualBasic.ChrW(10) & "asdfasdfasdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asd" & Global.Microsoft.VisualBasic.ChrW(10) & "fa" &
    "s" & Global.Microsoft.VisualBasic.ChrW(10) & "dfas" & Global.Microsoft.VisualBasic.ChrW(10) & "df" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "asdf" & Global.Microsoft.VisualBasic.ChrW(10) & "sadf" & Global.Microsoft.VisualBasic.ChrW(10) & "sadfasdasdffasd" & Global.Microsoft.VisualBasic.ChrW(10) & "as" & Global.Microsoft.VisualBasic.ChrW(10) & "dfas" & Global.Microsoft.VisualBasic.ChrW(10) & "df" & Global.Microsoft.VisualBasic.ChrW(10) & "asdfasdf"
        '
        'Button_TestClick
        '
        Me.Button_TestClick.Location = New System.Drawing.Point(79, 175)
        Me.Button_TestClick.Name = "Button_TestClick"
        Me.Button_TestClick.Size = New System.Drawing.Size(66, 23)
        Me.Button_TestClick.TabIndex = 8
        Me.Button_TestClick.Text = "Test Click"
        Me.Button_TestClick.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 132)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Easing Function"
        '
        'ComboBox_EasingFunction
        '
        Me.ComboBox_EasingFunction.FormattingEnabled = True
        Me.ComboBox_EasingFunction.Location = New System.Drawing.Point(10, 148)
        Me.ComboBox_EasingFunction.Name = "ComboBox_EasingFunction"
        Me.ComboBox_EasingFunction.Size = New System.Drawing.Size(141, 21)
        Me.ComboBox_EasingFunction.TabIndex = 6
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TextBox_FPS)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Location = New System.Drawing.Point(13, 47)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(138, 21)
        Me.Panel4.TabIndex = 2
        '
        'TextBox_FPS
        '
        Me.TextBox_FPS.Location = New System.Drawing.Point(93, 0)
        Me.TextBox_FPS.Name = "TextBox_FPS"
        Me.TextBox_FPS.Size = New System.Drawing.Size(42, 20)
        Me.TextBox_FPS.TabIndex = 2
        Me.TextBox_FPS.Text = "72"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(3, 1)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label4.Size = New System.Drawing.Size(27, 19)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "FPS"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Button_State_Reset)
        Me.GroupBox2.Controls.Add(Me.FlowLayoutPanel1)
        Me.GroupBox2.Controls.Add(Me.Label_StateValue)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 309)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(513, 201)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Events"
        '
        'Button_State_Reset
        '
        Me.Button_State_Reset.Location = New System.Drawing.Point(181, 19)
        Me.Button_State_Reset.Name = "Button_State_Reset"
        Me.Button_State_Reset.Size = New System.Drawing.Size(65, 23)
        Me.Button_State_Reset.TabIndex = 12
        Me.Button_State_Reset.Text = "Reset"
        Me.Button_State_Reset.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_LeftDown)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_LeftUp)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_LeftClick)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_LeftDoubleClick)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_RightDown)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_RightUp)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_RightClick)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_MiddleDown)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_MiddleUp)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_MiddleClick)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_ScrollDown)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button_Event_ScrollUp)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(22, 55)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(463, 121)
        Me.FlowLayoutPanel1.TabIndex = 25
        '
        'Button_Event_LeftDown
        '
        Me.Button_Event_LeftDown.Location = New System.Drawing.Point(3, 3)
        Me.Button_Event_LeftDown.Name = "Button_Event_LeftDown"
        Me.Button_Event_LeftDown.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_LeftDown.TabIndex = 11
        Me.Button_Event_LeftDown.Text = "LeftDown"
        Me.Button_Event_LeftDown.UseVisualStyleBackColor = True
        '
        'Button_Event_LeftUp
        '
        Me.Button_Event_LeftUp.Location = New System.Drawing.Point(121, 3)
        Me.Button_Event_LeftUp.Name = "Button_Event_LeftUp"
        Me.Button_Event_LeftUp.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_LeftUp.TabIndex = 12
        Me.Button_Event_LeftUp.Text = "LeftUp"
        Me.Button_Event_LeftUp.UseVisualStyleBackColor = True
        '
        'Button_Event_LeftClick
        '
        Me.Button_Event_LeftClick.Location = New System.Drawing.Point(239, 3)
        Me.Button_Event_LeftClick.Name = "Button_Event_LeftClick"
        Me.Button_Event_LeftClick.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_LeftClick.TabIndex = 13
        Me.Button_Event_LeftClick.Text = "LeftClick"
        Me.Button_Event_LeftClick.UseVisualStyleBackColor = True
        '
        'Button_Event_LeftDoubleClick
        '
        Me.Button_Event_LeftDoubleClick.Location = New System.Drawing.Point(3, 32)
        Me.Button_Event_LeftDoubleClick.Name = "Button_Event_LeftDoubleClick"
        Me.Button_Event_LeftDoubleClick.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_LeftDoubleClick.TabIndex = 14
        Me.Button_Event_LeftDoubleClick.Text = "LeftDoubleClick"
        Me.Button_Event_LeftDoubleClick.UseVisualStyleBackColor = True
        '
        'Button_Event_RightDown
        '
        Me.Button_Event_RightDown.Location = New System.Drawing.Point(121, 32)
        Me.Button_Event_RightDown.Name = "Button_Event_RightDown"
        Me.Button_Event_RightDown.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_RightDown.TabIndex = 16
        Me.Button_Event_RightDown.Text = "RightDown"
        Me.Button_Event_RightDown.UseVisualStyleBackColor = True
        '
        'Button_Event_RightUp
        '
        Me.Button_Event_RightUp.Location = New System.Drawing.Point(239, 32)
        Me.Button_Event_RightUp.Name = "Button_Event_RightUp"
        Me.Button_Event_RightUp.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_RightUp.TabIndex = 17
        Me.Button_Event_RightUp.Text = "RightUp"
        Me.Button_Event_RightUp.UseVisualStyleBackColor = True
        '
        'Button_Event_RightClick
        '
        Me.Button_Event_RightClick.Location = New System.Drawing.Point(3, 61)
        Me.Button_Event_RightClick.Name = "Button_Event_RightClick"
        Me.Button_Event_RightClick.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_RightClick.TabIndex = 18
        Me.Button_Event_RightClick.Text = "RightClick"
        Me.Button_Event_RightClick.UseVisualStyleBackColor = True
        '
        'Button_Event_MiddleDown
        '
        Me.Button_Event_MiddleDown.Location = New System.Drawing.Point(121, 61)
        Me.Button_Event_MiddleDown.Name = "Button_Event_MiddleDown"
        Me.Button_Event_MiddleDown.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_MiddleDown.TabIndex = 21
        Me.Button_Event_MiddleDown.Text = "MiddleDown"
        Me.Button_Event_MiddleDown.UseVisualStyleBackColor = True
        '
        'Button_Event_MiddleUp
        '
        Me.Button_Event_MiddleUp.Location = New System.Drawing.Point(239, 61)
        Me.Button_Event_MiddleUp.Name = "Button_Event_MiddleUp"
        Me.Button_Event_MiddleUp.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_MiddleUp.TabIndex = 22
        Me.Button_Event_MiddleUp.Text = "MiddleUp"
        Me.Button_Event_MiddleUp.UseVisualStyleBackColor = True
        '
        'Button_Event_MiddleClick
        '
        Me.Button_Event_MiddleClick.Location = New System.Drawing.Point(3, 90)
        Me.Button_Event_MiddleClick.Name = "Button_Event_MiddleClick"
        Me.Button_Event_MiddleClick.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_MiddleClick.TabIndex = 23
        Me.Button_Event_MiddleClick.Text = "MiddleClick"
        Me.Button_Event_MiddleClick.UseVisualStyleBackColor = True
        '
        'Button_Event_ScrollDown
        '
        Me.Button_Event_ScrollDown.Location = New System.Drawing.Point(121, 90)
        Me.Button_Event_ScrollDown.Name = "Button_Event_ScrollDown"
        Me.Button_Event_ScrollDown.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_ScrollDown.TabIndex = 24
        Me.Button_Event_ScrollDown.Text = "ScrollDown"
        Me.Button_Event_ScrollDown.UseVisualStyleBackColor = True
        '
        'Button_Event_ScrollUp
        '
        Me.Button_Event_ScrollUp.Location = New System.Drawing.Point(239, 90)
        Me.Button_Event_ScrollUp.Name = "Button_Event_ScrollUp"
        Me.Button_Event_ScrollUp.Size = New System.Drawing.Size(112, 23)
        Me.Button_Event_ScrollUp.TabIndex = 25
        Me.Button_Event_ScrollUp.Text = "ScrollUp"
        Me.Button_Event_ScrollUp.UseVisualStyleBackColor = True
        '
        'Label_StateValue
        '
        Me.Label_StateValue.AutoSize = True
        Me.Label_StateValue.Location = New System.Drawing.Point(61, 24)
        Me.Label_StateValue.Name = "Label_StateValue"
        Me.Label_StateValue.Size = New System.Drawing.Size(34, 13)
        Me.Label_StateValue.TabIndex = 10
        Me.Label_StateValue.Text = "Value"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(19, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "State:"
        '
        'Button_RecentreWindow
        '
        Me.Button_RecentreWindow.Location = New System.Drawing.Point(12, 32)
        Me.Button_RecentreWindow.Name = "Button_RecentreWindow"
        Me.Button_RecentreWindow.Size = New System.Drawing.Size(66, 23)
        Me.Button_RecentreWindow.TabIndex = 9
        Me.Button_RecentreWindow.Text = "ReCentre Window"
        Me.Button_RecentreWindow.UseVisualStyleBackColor = True
        '
        'CheckBox_LogActivity
        '
        Me.CheckBox_LogActivity.AutoSize = True
        Me.CheckBox_LogActivity.Checked = True
        Me.CheckBox_LogActivity.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_LogActivity.Location = New System.Drawing.Point(84, 36)
        Me.CheckBox_LogActivity.Name = "CheckBox_LogActivity"
        Me.CheckBox_LogActivity.Size = New System.Drawing.Size(122, 17)
        Me.CheckBox_LogActivity.TabIndex = 10
        Me.CheckBox_LogActivity.Text = "Console Log Activity"
        Me.CheckBox_LogActivity.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(537, 24)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 522)
        Me.Controls.Add(Me.CheckBox_LogActivity)
        Me.Controls.Add(Me.Button_RecentreWindow)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "HookMouse"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button_TestAll As Button
    Friend WithEvents TextBox_X As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox_Y As TextBox
    Friend WithEvents Label_XValue As Label
    Friend WithEvents Label_YValue As Label
    Friend WithEvents Timer_UpdateUI As Timer
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox_Duration As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox_FPS As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox_EasingFunction As ComboBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Button_Event_LeftDoubleClick As Button
    Friend WithEvents Label_StateValue As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button_Event_LeftClick As Button
    Friend WithEvents Button_Event_LeftUp As Button
    Friend WithEvents Button_Event_LeftDown As Button
    Friend WithEvents Button_TestClick As Button
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Button_Event_MiddleClick As Button
    Friend WithEvents Button_Event_MiddleUp As Button
    Friend WithEvents Button_Event_MiddleDown As Button
    Friend WithEvents Button_Event_RightClick As Button
    Friend WithEvents Button_Event_RightUp As Button
    Friend WithEvents Button_Event_RightDown As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Button_Event_ScrollDown As Button
    Friend WithEvents Button_Event_ScrollUp As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Button_State_Reset As Button
    Friend WithEvents Button_TestClickAndDrag As Button
    Friend WithEvents Button_RecentreWindow As Button
    Friend WithEvents Button_Test As Button
    Friend WithEvents CheckBox_LogActivity As CheckBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
End Class
