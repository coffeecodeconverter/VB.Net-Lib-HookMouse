﻿


Imports System.Threading
Imports System.Windows.Forms.VisualStyles.VisualStyleElement



Public Class Form1



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Initialize()
        Timer_UpdateUI.Start()
        ComboBox_EasingFunction.Items.AddRange(easingFunctions.Keys.ToArray())
        ComboBox_EasingFunction.SelectedItem = "EaseOutQuint"
        Label_StateValue.Text = ""

        If CheckBox_LogActivity.Checked = True Then
            logMouseActivity = True
        Else
            logMouseActivity = False
        End If
    End Sub



    Private Sub Button_RecentreWindow_Click(sender As Object, e As EventArgs) Handles Button_RecentreWindow.Click
        Me.Size = New Size(553, 561)
        ReCentreForm()
    End Sub



    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim message As String = $"
Version: {versionNumber_HookMouse} {vbCrLf}
This module gives you full control for simulating mouse events.

Its able to smoothly animate mouse movements too, with a variety of easing functions for asthetics.
You can chain events together to build automation routines. 
"
        MessageBox.Show(Message, "About HookMouse", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub




    Private Sub ReCentreForm()
        Me.Location = New Point((Screen.PrimaryScreen.WorkingArea.Width - Me.Width) \ 2,
                    ((Screen.PrimaryScreen.WorkingArea.Height - Me.Height) \ 2) + 40)
    End Sub


    Private Sub Timer_UpdateUI_Tick(sender As Object, e As EventArgs) Handles Timer_UpdateUI.Tick
        Dim mousePos As Point = MousePosition
        Label_XValue.Text = mousePos.X.ToString()
        Label_YValue.Text = mousePos.Y.ToString()
    End Sub




    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub


    Private Async Sub Button_Test_Click_1(sender As Object, e As EventArgs) Handles Button_Test.Click
        Dim x As Integer = CInt(TextBox_X.Text)
        Dim y As Integer = CInt(TextBox_Y.Text)
        Dim duration As Integer = CInt(TextBox_Duration.Text)
        Dim fps As Integer = CInt(TextBox_FPS.Text)
        Dim easingFunction As String = ComboBox_EasingFunction.SelectedItem.ToString()

        Await HookMouse.MoveCursor(x, y, duration, fps, easingFunctions(easingFunction))
    End Sub






    Private Sub Button_TestClick_Click(sender As Object, e As EventArgs) Handles Button_TestClick.Click
        ' DO NOTHING - use the mouseDown and MouseUp Events instead below 
        ReCentreForm()
    End Sub


    Private Sub Button_TestClick_MouseDown(sender As Object, e As MouseEventArgs) Handles Button_TestClick.MouseDown
        'Console.WriteLine("down " & DateTime.Now.ToString("HH:mm:ss:ffffff"))
        RichTextBox1.AppendText("down " & DateTime.Now.ToString("HH:mm:ss:ffffff") & vbCrLf)
        RichTextBox1.Select(RichTextBox1.MaxLength, 1)
        RichTextBox1.ScrollToCaret()
    End Sub

    Private Sub Button_TestClick_MouseUp(sender As Object, e As MouseEventArgs) Handles Button_TestClick.MouseUp
        'Console.WriteLine("up   " & DateTime.Now.ToString("HH:mm:ss:ffffff") & vbCrLf)
        RichTextBox1.AppendText("up   " & DateTime.Now.ToString("HH:mm:ss:ffffff") & vbCrLf & vbCrLf)
        RichTextBox1.Select(RichTextBox1.MaxLength, 1)
        RichTextBox1.ScrollToCaret()
    End Sub






    Private Async Sub Button_TestClickAndDrag_Click(sender As Object, e As EventArgs) Handles Button_TestClickAndDrag.Click
        ReCentreForm()

        Dim duration As Integer = CInt(TextBox_Duration.Text)
        Dim fps As Integer = CInt(TextBox_FPS.Text)
        Dim easingFunction As String = ComboBox_EasingFunction.SelectedItem.ToString()


        Await ClickAndDrag(824, 294, 276, 96, duration, fps, easingFunctions(easingFunction))


        Await HookMouse.MoveCursor(182, 135, duration, fps, easingFunctions(easingFunction))
        HookMouse.DoLeftClick()

        Await HookMouse.MoveCursor(800, 600, duration, fps, easingFunctions(easingFunction))
    End Sub




    Private Async Sub Button_TestAll_Click(sender As Object, e As EventArgs) Handles Button_TestAll.Click

        ReCentreForm()

        Dim duration As Integer = CInt(TextBox_Duration.Text)
        Dim fps As Integer = CInt(TextBox_FPS.Text)
        Dim easingFunction As String = ComboBox_EasingFunction.SelectedItem.ToString()



        Await HookMouse.MoveCursor(936, 468, duration, fps, easingFunctions(easingFunction))
        Await HookMouse.DoKeepMouseInPlace()
        HookMouse.DoLeftClick()


        Await HookMouse.DoMouseScroll(-5)


        Await HookMouse.MoveCursor(753, 465, duration, fps, easingFunctions(easingFunction))
        HookMouse.DoLeftDoubleClick()


        Await HookMouse.MoveCursor(936, 468, duration, fps, easingFunctions(easingFunction))
        HookMouse.DoLeftClick()


        Await HookMouse.DoMouseScroll(5)


        Await HookMouse.MoveCursor(827, 469, duration, fps, easingFunctions(easingFunction))
        HookMouse.DoLeftDoubleClick()


        Await HookMouse.MoveCursor(800, 600, duration, fps, easingFunctions(easingFunction))
    End Sub







    Private Sub Button_State_Reset_Click(sender As Object, e As EventArgs) Handles Button_State_Reset.Click
        HookMouse.ResetMouseState()
        Label_StateValue.Text = " - cleared - "
    End Sub
















    Private Async Sub Button_Event_LeftDown_Click(sender As Object, e As EventArgs) Handles Button_Event_LeftDown.Click
        HookMouse.DoLeftDown()
        Label_StateValue.Text = "left mouse down"
        Await NonBlockingWait(100)
        Button_Event_LeftDown.Focus()
    End Sub


    Private Sub Button_Event_LeftUp_Click(sender As Object, e As EventArgs) Handles Button_Event_LeftUp.Click
        HookMouse.DoLeftUp()
        Label_StateValue.Text = "left mouse up"
        Button_Event_LeftUp.Focus()
    End Sub


    Private Async Sub Button_Event_LeftClick_Click(sender As Object, e As EventArgs) Handles Button_Event_LeftClick.Click
        HookMouse.DoLeftClick()
        Label_StateValue.Text = "left click"
        Button_Event_LeftClick.Focus()
    End Sub



    Private Async Sub Button_Event_LeftDoubleClick_Click(sender As Object, e As EventArgs) Handles Button_Event_LeftDoubleClick.Click
        HookMouse.DoLeftDoubleClick()
        Label_StateValue.Text = "left double-click"
        Button_Event_LeftDoubleClick.Focus()
    End Sub



    Private Sub Button_Event_RightDown_Click(sender As Object, e As EventArgs) Handles Button_Event_RightDown.Click
        HookMouse.DoRightDown()
        Label_StateValue.Text = "right mouse down"
        Button_Event_RightDown.Focus()
    End Sub

    Private Sub Button_Event_RightUp_Click(sender As Object, e As EventArgs) Handles Button_Event_RightUp.Click
        HookMouse.DoRightUp()
        Label_StateValue.Text = "right mouse up"
        Button_Event_RightUp.Focus()
    End Sub

    Private Sub Button_Event_RightClick_Click(sender As Object, e As EventArgs) Handles Button_Event_RightClick.Click
        HookMouse.DoRightClick()
        Label_StateValue.Text = "right click"
        Button_Event_RightClick.Focus()
    End Sub




    Private Sub Button_Event_MiddleDown_Click(sender As Object, e As EventArgs) Handles Button_Event_MiddleDown.Click
        HookMouse.DoMiddleDown()
        Label_StateValue.Text = "middle mouse down"
        Button_Event_MiddleDown.Focus()
    End Sub

    Private Sub Button_Event_MiddleUp_Click(sender As Object, e As EventArgs) Handles Button_Event_MiddleUp.Click
        HookMouse.DoMiddleUp()
        Label_StateValue.Text = "middle mouse up"
        Button_Event_MiddleUp.Focus()
    End Sub

    Private Sub Button_Event_MiddleClick_Click(sender As Object, e As EventArgs) Handles Button_Event_MiddleClick.Click
        HookMouse.DoMiddleClick()
        Label_StateValue.Text = "middle mouse click"
        Button_Event_MiddleClick.Focus()
    End Sub







    Private Sub Button_Event_ScrollDown_Click(sender As Object, e As EventArgs) Handles Button_Event_ScrollDown.Click
        HookMouse.DoMouseScroll(-1)
        Label_StateValue.Text = "scroll down"
        Button_Event_ScrollDown.Focus()
    End Sub

    Private Sub Button_Event_ScrollUp_Click(sender As Object, e As EventArgs) Handles Button_Event_ScrollUp.Click
        HookMouse.DoMouseScroll(1)
        Label_StateValue.Text = "scroll up"
        Button_Event_ScrollUp.Focus()
    End Sub









    Private Sub MyCallBackFunction()
        MsgBox("this is the call back function")
    End Sub







    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub




End Class

